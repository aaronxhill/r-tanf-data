library("ggplot2")

setwd("/Users/Aaron_hill/Dropbox/Documents/mdrc/2018consulting/tdi_ta_data/aspe/tanf09")
# Set working directory to folder containing GitRepo

# Read in case data and review basic data structure
ssp09a <- read.csv("ssp09a.csv", stringsAsFactors=FALSE, header=TRUE)
head(cases)
dim(cases)

ssp09c <- read.csv("ssp09c.csv", stringsAsFactors=FALSE, header=TRUE)
head(cases)
dim(cases)

tanf09a <- read.csv("tanf09a.csv", stringsAsFactors=FALSE, header=TRUE)
head(cases)
dim(cases)

tanf09c <- read.csv("tanf09c.csv", stringsAsFactors=FALSE, header=TRUE)
head(cases)
dim(cases)
